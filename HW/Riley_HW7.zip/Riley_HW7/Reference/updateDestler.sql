UPDATE contact
SET contactID=20
WHERE contactID=1;

SELECT *
FROM phone;

SELECT *
FROM company;

SELECT * 
FROM contact;

SELECT * 
FROM co_worker;

SELECT *
FROM personal;


SELECT * 
FROM friend;

SELECT *
FROM contact_phone;

